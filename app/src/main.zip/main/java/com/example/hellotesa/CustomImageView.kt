package com.example.hellotesa

import android.content.Context
import android.graphics.Bitmap
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View.OnTouchListener
import androidx.appcompat.widget.AppCompatImageView

class CustomImageView : AppCompatImageView {
    private var bitmap: Bitmap? = null
    private var onImageTouchListener: OnImageTouchListener? = null

    constructor(context: Context?) : super(context!!) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(
        context!!, attrs
    ) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context!!, attrs, defStyleAttr
    ) {
        init()
    }

    private fun init() {
        setOnTouchListener(OnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                if (onImageTouchListener != null) {
                    val x = event.x.toInt()
                    val y = event.y.toInt()
                    onImageTouchListener!!.onImageTouch(x, y)
                }
                performClick()
                return@OnTouchListener true
            }
            false
        })
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun setBitmap(bitmap: Bitmap?) {
        this.bitmap = bitmap
        setImageBitmap(bitmap)
    }

    fun setOnImageTouchListener(listener: OnImageTouchListener?) {
        onImageTouchListener = listener
    }

    interface OnImageTouchListener {
        fun onImageTouch(x: Int, y: Int)
    }
}

