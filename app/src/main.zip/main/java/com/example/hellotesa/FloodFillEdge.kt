package com.example.hellotesa

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.opencv.android.OpenCVLoader
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import org.opencv.core.Core
import java.io.IOException

class FloodFillEdge : AppCompatActivity() {

    private var uploadedImage: Bitmap? = null
    private lateinit var customImageView: CustomImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flood_fill_edge)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        customImageView = findViewById(R.id.imageView3)

        val selectImageButton = findViewById<Button>(R.id.btnOpenGallery2)
        selectImageButton.setOnClickListener { openGallery() }

        customImageView.setOnImageTouchListener(object : CustomImageView.OnImageTouchListener {
            override fun onImageTouch(x: Int, y: Int) {
                uploadedImage?.let {
                    val scaledPoint = mapTouchToImageCoordinates(customImageView, it, x, y)
                    val resultBitmap = processImage(it, scaledPoint)
                    customImageView.setBitmap(resultBitmap)
                }
            }
        })

        if (!OpenCVLoader.initDebug()) {
            println("Error loading OpenCV")
        } else {
            println("OpenCV loaded successfully")
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, 101)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK && data != null && data.data != null) {
            val imageUri: Uri? = data.data
            try {
                imageUri?.let {
                    val options = BitmapFactory.Options()
                    options.inSampleSize = calculateInSampleSize(options, 1024, 1024)
                    uploadedImage = BitmapFactory.decodeStream(contentResolver.openInputStream(it), null, options)
                    uploadedImage = uploadedImage?.copy(Bitmap.Config.ARGB_8888, true) // Convert to mutable

                    customImageView.setBitmap(uploadedImage)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.run { outHeight to outWidth }
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun mapTouchToImageCoordinates(imageView: CustomImageView, bitmap: Bitmap, x: Int, y: Int): Point {
        val imageViewWidth = imageView.width.toFloat()
        val imageViewHeight = imageView.height.toFloat()
        val imageWidth = bitmap.width.toFloat()
        val imageHeight = bitmap.height.toFloat()

        val scale: Float
        val offsetX: Float
        val offsetY: Float

        if (imageViewWidth / imageWidth < imageViewHeight / imageHeight) {
            scale = imageViewWidth / imageWidth
            offsetX = 0f
            offsetY = (imageViewHeight - imageHeight * scale) / 2f
        } else {
            scale = imageViewHeight / imageHeight
            offsetX = (imageViewWidth - imageWidth * scale) / 2f
            offsetY = 0f
        }

        val scaledX = ((x - offsetX) / scale).toInt()
        val scaledY = ((y - offsetY) / scale).toInt()

        return Point(scaledX.toDouble(), scaledY.toDouble())
    }

    private fun processImage(bitmap: Bitmap, point: Point): Bitmap {
        // Convert Bitmap to Mat
        val src = Mat()
        val bitmap32 = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        org.opencv.android.Utils.bitmapToMat(bitmap32, src)

        // Convert to 3 channels (BGR)
        val bgr = Mat()
        Imgproc.cvtColor(src, bgr, Imgproc.COLOR_RGBA2BGR)

        // Apply edge detection
        val edges = Mat()
        Imgproc.Canny(bgr, edges, 100.0, 200.0)
        println("Edges detected: ${Core.countNonZero(edges)}")

        // Dilate the edges to create a more pronounced boundary
        val kernel = Mat.ones(Size(3.0, 3.0), CvType.CV_8U)
        Imgproc.dilate(edges, edges, kernel)
        println("Edges dilated: ${Core.countNonZero(edges)}")

        // Create a mask for the flood fill operation
        val mask = Mat(bgr.rows() + 2, bgr.cols() + 2, CvType.CV_8UC1, Scalar(0.0))
        edges.copyTo(mask.rowRange(1, mask.rows() - 1).colRange(1, mask.cols() - 1))

        // Define the color to be blended (red in this case)
        val blendColor = Scalar(0.0, 0.0, 255.0) // Red in BGR

        // Perform flood fill with tighter tolerances
        val lowerDiff = Scalar(30.0, 30.0, 30.0)
        val upperDiff = Scalar(30.0, 30.0, 30.0)
        Imgproc.floodFill(bgr, mask, point, blendColor, null, lowerDiff, upperDiff, Imgproc.FLOODFILL_MASK_ONLY or Imgproc.FLOODFILL_FIXED_RANGE)
        println("Flood fill completed")

        // Convert the flood-filled image back to 4 channels (BGRA) to match the original
        val floodFilled = Mat()
        Imgproc.cvtColor(bgr, floodFilled, Imgproc.COLOR_BGR2BGRA)

        // Blend the color with the original texture
        Core.addWeighted(floodFilled, 0.5, src, 0.5, 0.0, src)

        // Convert the processed Mat back to Bitmap
        val resultBitmap = Bitmap.createBitmap(src.cols(), src.rows(), Bitmap.Config.ARGB_8888)
        org.opencv.android.Utils.matToBitmap(src, resultBitmap)

        return resultBitmap
    }
}
