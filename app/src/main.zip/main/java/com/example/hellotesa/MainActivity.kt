package com.example.hellotesa

import android.Manifest.permission.CAMERA
import android.Manifest.permission.READ_EXTERNAL_STORAGE
import android.Manifest.permission.READ_MEDIA_IMAGES
import android.Manifest.permission.READ_MEDIA_VIDEO
import android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class MainActivity : AppCompatActivity() {
    private val GALLERY_REQUEST_CODE = 101
    private lateinit var imageView: ImageView
    private lateinit var tflite: Interpreter
    private var originalBitmap: Bitmap? = null
    private var processedBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
/*
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
*/

        // Register ActivityResult handler
        val requestPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val granted = results.all { it.value }
            if (granted) {
                // Permissions granted, proceed with storage access
                Toast.makeText(this, "Permissions granted!", Toast.LENGTH_SHORT).show()
            } else {
                // Permissions denied, handle case (e.g., explain to user)
                Toast.makeText(this, "Storage permissions denied", Toast.LENGTH_SHORT).show()
            }
        }

        // Permission request logic
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestPermissions.launch(arrayOf(READ_MEDIA_IMAGES, READ_MEDIA_VIDEO, READ_MEDIA_VISUAL_USER_SELECTED, CAMERA))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions.launch(arrayOf(READ_MEDIA_IMAGES, READ_MEDIA_VIDEO, CAMERA))
        } else {
            requestPermissions.launch(arrayOf(READ_EXTERNAL_STORAGE, CAMERA))
        }

        // Initialize TensorFlow Lite interpreter
        try {
            tflite = Interpreter(loadModelFile(this))
        } catch (e: Exception) {
            e.printStackTrace()
            showToast("Error initializing TensorFlow Lite interpreter.")
        }

        val galleryPopButton = findViewById<Button>(R.id.galleryPopButton)
        galleryPopButton.setOnClickListener {
            goToCameraActivity()
        }

        val floodFillBtn = findViewById<Button>(R.id.btnfloodfill)
        floodFillBtn.setOnClickListener{
            startActivity(Intent(this, FloodFillActivity::class.java))
        }

        val floodFillBtn2 = findViewById<Button>(R.id.btnfloodfill2)
        floodFillBtn2.setOnClickListener{
            startActivity(Intent(this, FloodFillEdge::class.java))
        }

        val changeColorButton: Button = findViewById(R.id.colorChangeButton)
        changeColorButton.setOnClickListener {
            println("here")
            originalBitmap?.let {
                processedBitmap = runModelAndReplaceColor(it, Color.RED)
                imageView.setImageBitmap(processedBitmap)
            }
        }
    }

    private fun runModelAndReplaceColor(bitmap: Bitmap, color: Int): Bitmap {
        val segmentationMask = runModel(bitmap)
        return replaceWallColor(bitmap, segmentationMask, color)
    }

    private fun goToCameraActivity() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, GALLERY_REQUEST_CODE)
        } else {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            val selectedImageUri = data?.data
            if (selectedImageUri != null) {
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, selectedImageUri)
                imageView = findViewById(R.id.imageView)
                imageView.setImageURI(selectedImageUri)
                if (::tflite.isInitialized) {
                    runClassification(bitmap)
                } else {
                    Toast.makeText(this, "TensorFlow Lite interpreter is not initialized", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun processOutput(output: FloatArray): String {
        val maxIndex = output.indices.maxByOrNull { output[it] } ?: -1
        return "Class $maxIndex with confidence ${output[maxIndex]}"
    }

    private fun runClassification(bitmap: Bitmap) {
        val inputShape = tflite.getInputTensor(0).shape()
        val height = inputShape[1]
        val width = inputShape[2]

        val inputImageBuffer = convertBitmapToByteBuffer(bitmap, width, height)

        val outputShape = tflite.getOutputTensor(0).shape()
        val outputHeight = outputShape[1]
        val outputWidth = outputShape[2]
        val numClasses = outputShape[3]

        val output = Array(1) { Array(outputHeight) { Array(outputWidth) { FloatArray(numClasses) } } }

        tflite.run(inputImageBuffer, output)
        val segmentationBitmap = processOutput(output)

        val imageView = findViewById<ImageView>(R.id.imageView)
        imageView.setImageBitmap(segmentationBitmap)
        Toast.makeText(this, "Segmentation Completed", Toast.LENGTH_SHORT).show()
    }

    private fun convertBitmapToByteBuffer(bitmap: Bitmap, width: Int, height: Int): ByteBuffer {
        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, width, height, true)
        val numPixels = width * height
        val bytesPerChannel = 4 // 4 bytes per float
        val numChannels = 3 // RGB channels
        val totalBufferSize = numPixels * numChannels * bytesPerChannel

        val byteBuffer = ByteBuffer.allocateDirect(totalBufferSize).apply {
            order(ByteOrder.nativeOrder())
        }

        val intValues = IntArray(numPixels)
        resizedBitmap.getPixels(intValues, 0, width, 0, 0, width, height)
        for (pixelValue in intValues) {
            // Convert pixel to floats and normalize
            byteBuffer.putFloat(((pixelValue shr 16 and 0xFF) / 255.0f)) // Red
            byteBuffer.putFloat(((pixelValue shr 8 and 0xFF) / 255.0f)) // Green
            byteBuffer.putFloat((pixelValue and 0xFF) / 255.0f) // Blue
        }
        return byteBuffer
    }

    // Adjust the processOutput function to handle the new output format
    private fun processOutput(output: Array<Array<Array<FloatArray>>>): Bitmap {
        val outputHeight = output[0].size
        val outputWidth = output[0][0].size
        val numClasses = output[0][0][0].size

        val segmentationBitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)

        for (i in 0 until outputHeight) {
            for (j in 0 until outputWidth) {
                val maxClassIdx = output[0][i][j].indices.maxByOrNull { output[0][i][j][it] } ?: 0
                val color = getColorForClass(maxClassIdx)
                segmentationBitmap.setPixel(j, i, color)
            }
        }
        return segmentationBitmap
    }

    private fun getColorForClass(classIdx: Int): Int {
        // Define colors for your classes
        val colors = arrayOf(
            Color.TRANSPARENT, // class 0: background (example)
            Color.RED,         // class 1
            Color.GREEN,       // class 2
            // Add more colors as needed for other classes
        )
        return colors[classIdx % colors.size]
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    @Throws(IOException::class)
    private fun loadModelFile(context: Context): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd("deeplabv3.tflite")
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    private fun runModel(bitmap: Bitmap): Array<Array<Array<FloatArray>>> {
        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 257, 257, false)
        val inputBuffer = ByteBuffer.allocateDirect(1 * 257 * 257 * 3 * 4).apply {
            order(ByteOrder.nativeOrder())
        }
        val intValues = IntArray(257 * 257)
        resizedBitmap.getPixels(intValues, 0, 257, 0, 0, 257, 257)
        var pixel = 0
        for (i in 0 until 257) {
            for (j in 0 until 257) {
                val v = intValues[pixel++]
                inputBuffer.putFloat(((v shr 16) and 0xFF) / 255.0f)
                inputBuffer.putFloat(((v shr 8) and 0xFF) / 255.0f)
                inputBuffer.putFloat((v and 0xFF) / 255.0f)
            }
        }
        val output = Array(1) { Array(257) { Array(257) { FloatArray(21) } } }
        tflite.run(inputBuffer, output)
        return output
    }

    private fun replaceWallColor(bitmap: Bitmap, segmentationMask: Array<Array<Array<FloatArray>>>, selectedColor: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val outputBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)

        for (y in 0 until height) {
            for (x in 0 until width) {
                if (isWallSegment(segmentationMask, x, y)) {
                    outputBitmap.setPixel(x, y, selectedColor)
                }
            }
        }
        return outputBitmap
    }

    private fun isWallSegment(segmentationMask: Array<Array<Array<FloatArray>>>, x: Int, y: Int): Boolean {
        val wallClassIndex = 15
        return segmentationMask[0][y][x][wallClassIndex] > 0.5
    }
}
